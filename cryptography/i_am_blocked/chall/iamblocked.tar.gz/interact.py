from Crypto.Util.number import bytes_to_long, long_to_bytes, getPrime
import socket
import threading

BLOCKSIZE=4
p = getPrime(2048)
q = getPrime(2048)
N = p*q
phi = (p-1)*(q-1)
e = 0x10001
d = pow(e, -1, phi)

def RSA_encrypt(b:int):
	return pow(b, e, N)

def RSA_decrypt(b:int):
	return pow(b, d, N)

def encrypt(m:bytes):
	# Padding
	while len(m)%BLOCKSIZE != 0:
		m += b"A"
	plain = [bytes_to_long(m[BLOCKSIZE*i:BLOCKSIZE*i+BLOCKSIZE]) for i in range(len(m)//BLOCKSIZE)]
	cipher = [RSA_encrypt(c) for c in plain]	
	return cipher

def print_crypt(m, cs):
	for block in encrypt(m):
		cs.sendall((str(block)+"\n").encode())

def main(client_socket, client_address):
	client_socket.sendall(b"Welcome to Uruguay's server.\nPress ENTER to receive the data >")
	client_socket.recv(1024)
	print_crypt(open("flag.txt", "rb").read(), client_socket)
	while True:
		client_socket.sendall(b"Encrypt what ?")
		message = client_socket.recv(1024).strip()
		print_crypt(message, client_socket)

PORT=12345
server_socket=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('0.0.0.0', PORT))
server_socket.listen(16)
print(f"---START LISTEN {PORT}---")

while True:
	client_socket, client_address = server_socket.accept()
	print(f"---CONN FROM {client_address}---")

	ch = threading.Thread(target=main, args=(client_socket, client_address))
	ch.start()

