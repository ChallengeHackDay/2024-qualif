from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from datetime import datetime
from binascii import hexlify, unhexlify
import socket
import threading
	
key = get_random_bytes(32)
flag = "HACKDAY{This_15_SH0wTime}"
badword = ['admin','\'','true','false','syndicat','agence']
message = ' /$$   /$$  /$$$$$$   /$$$$$$  /$$   /$$ /$$$$$$$   /$$$$$$  /$$     /$$\n| $$  | $$ /$$__  $$ /$$__  $$| $$  /$$/| $$__  $$ /$$__  $$|  $$   /$$/\n| $$  | $$| $$  \ $$| $$  \__/| $$ /$$/ | $$  \ $$| $$  \ $$ \  $$ /$$/ \n| $$$$$$$$| $$$$$$$$| $$      | $$$$$/  | $$  | $$| $$$$$$$$  \  $$$$/  \n| $$__  $$| $$__  $$| $$      | $$  $$  | $$  | $$| $$__  $$   \  $$/   \n| $$  | $$| $$  | $$| $$    $$| $$\  $$ | $$  | $$| $$  | $$    | $$    \n| $$  | $$| $$  | $$|  $$$$$$/| $$ \  $$| $$$$$$$/| $$  | $$    | $$    \n|__/  |__/|__/  |__/ \______/ |__/  \__/|_______/ |__/  |__/    |__/\n'

def encrypt(data):
    iv = get_random_bytes(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return hexlify(iv + cipher.encrypt(pad(data.encode('utf-8'),AES.block_size)))

def decrypt(data):
    raw = unhexlify(data)
    cipher = AES.new(key, AES.MODE_CBC, raw[:AES.block_size])
    dec = unpad(cipher.decrypt(raw[AES.block_size:]), AES.block_size)
    print(dec.decode())
    return dec

def menu():
	while(True):
		input_ = input("Network of SYNDICAT\n[>A] Name Yourself\n[>B] Give your token\n > ")
		if(input_ == "A"):
			return 1
		elif(input_ == "B"):
			return 2

def createToken(username,profession):
	token = "username="+str(username)+"&agent=agence&profession="+str(profession)+"&admin=false&time="+str(datetime.timestamp(datetime.now()))
	print(token)
	return encrypt(token).decode('latin1')

def check(token):
	try:
		if("admin=true" in decrypt(token).decode('latin1') and "agent=syndicat" in decrypt(token).decode('latin1')):
			return 'All right, you really are an admin from SYNDICAT, here are your credentials : BootMaster:'+flag
		else:
			return 'You are not admin nor from syndicat !'
	except Exception as ex:
		print(ex)
		return "Error"

def main():
	print(message)
	while(True):
		if(menu()==1):
			username = input(" > Username : ")
			profession = input(" > Profession : ")
			isbad, isverybad = False, False
			for element in badword:
				if(element in username):
					isbad = True
					break
			for element in badword:
				if(element in profession):
					isverybad = True
					break
			if(isbad == True or isverybad == True):
				print('BadWord !!! "'+element+'"')
			else:
				print("Token : "+createToken(username,profession))
		else:
			token = input(" > Token : ")
			print(check(token))


main()

