import socket
from random import randint
from base64 import b64encode
import threading

def guess(word):
	return bytes([ord(letter) + randint(-1,1)*-1 for letter in word]+[10])

def handler(client_socket, client_address):
	client_socket.sendall(guess("Hello stranger."))
	client_socket.sendall(guess("Since you are so good at guessing, can you give me the number ?"))
	try:
		client_input = int(client_socket.recv(1024).decode().strip())
	except:
		client_socket.sendall(guess("No no no, this is not a number !"))
		client_input = 0
	if client_input == 42:
		client_socket.sendall(guess("Great ! Access to the secret file has been granted HACKDAY{N0T_So_GUESSY_HUH??} :"))
		client_socket.sendall(guess(b64encode(open("flag.txt", "rb").read()).decode()))
	else:
		client_socket.sendall(guess("No no no, this is not the good number !"))
	client_socket.close()

PORT=12345
server_socket=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('0.0.0.0', PORT))
server_socket.listen(16)
print(f"---START LISTEN {PORT}---")

while True:
	client_socket, client_address = server_socket.accept()
	print(f"---CONN FROM {client_address}---")

	ch = threading.Thread(target=handler, args=(client_socket, client_address))
	ch.start()
