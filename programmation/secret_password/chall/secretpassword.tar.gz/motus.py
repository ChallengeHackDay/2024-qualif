import socket
import threading
from random import randint
from string import ascii_lowercase,ascii_uppercase

conversation = b"""
As the door opens in front of you, you enter, and it clicks shut behind you. You walk silently down the corridor when you hear three voices engaged in conversation. It appears that the hackers are beginning their reunion...

Bootmaster: Hey, guys ! How's the night going ?
MemeMaker: Yo, Bootmaster! All good here, just making some memes to spice my next ransomwares. What's up, AntiRickRoll?
AntiRickRoll: Hi everyone ! I'm doing well, thanks. Just keeping the virtual barricades secure. Anything interesting happening lately?
Bootmaster: You guys won't believe the score we hit last night. Managed to breach that high-profile crypto exchange. It was like taking candy from a baby.
MemeMaker: No way! That's epic, bro. How much are we talking about?
Bootmaster: Around one million each. Not bad for a night's work, huh?
MemeMaker: Sweet! We're practically swimming in digital gold now.
AntiRickRoll: We make one hell of a team, guys.
MemeMaker: By the way, Liam, did you transfer your share to the offshore account?
Bootmaster: Dude, we don't use real names in this business. You know better.
MemeMaker: Oh, my bad, Bootmaster. I just slipped there for a moment.
Bootmaster: Slip-ups like that can cost us big time, MemeMaker. Keep it tight. We don't want any leaks.
MemeMaker: Yeah, you're right, Bootmaster. Won't happen again.
AntiRickRoll: Let's not dwell on that, guys. We got the cash, and that's what matters. What's our next move?
Bootmaster: Agreed. We'll talk about our next venture later. For now, let's lay low and enjoy the spoils. Keep those memes flowing, MemeMaker, just keep my name out of it.
MemeMaker: Got it, Bootmaster. My lips are sealed, and my memes are limitless.
AntiRickRoll: Alright, then. Until next time, fellas!
Bootmaster: Stay secure, guys.

As the reunion ends, you swiftly exit the place and go to report.
HACKDAY{Whispers_in_the_D4rk}"""

def create_word(charset, size):
	w=""
	for i in range(size):
		w += charset[randint(0,len(charset)-1)]
	return w

def check_word(w, uinput):
	count = 0
	for i in range(len(w)):
		if w[i] == uinput[i]:
			count += 1
	if count == len(w):
		return ("Excellent ! the word was {}\n".format(w)).encode()
	return ("{} character{} are correct\n".format(count,["s" if count > 1 else ""][0])).encode()

def handler(client_socket, client_address):
	for i in range(3):
		new_word = create_word(charsets[i], sizes[i])
		client_socket.sendall(("Charset is {}\nSize is {}\n".format(charsets[i],sizes[i])).encode())
		while True:
			client_socket.sendall(b">>> ")
			uinput = client_socket.recv(1024).decode().strip()
			if uinput == "I quit bro":
				client_socket.sendall(("The word was {}\n".format(new_word)).encode())
				exit()
			if len(uinput) != len(new_word):
				client_socket.sendall(("Bad length input. Expected {}, got {}\n".format(len(uinput), len(new_word))).encode())
				continue
			res = check_word(new_word, uinput)
			client_socket.sendall(res)
			if res.split(b" ")[0] == b"Excellent":
				client_socket.sendall(("Going to the next step. {}/3\n".format(i+1)).encode())
				break
	client_socket.sendall(conversation)
	client_socket.close()

charsets = [ascii_lowercase, ascii_lowercase+ascii_uppercase, ascii_lowercase+ascii_uppercase+"0123456789"]
sizes = [5, 15, 35]

PORT=12345
server_socket=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('0.0.0.0', PORT))
server_socket.listen(16)
print(f"---START LISTEN {PORT}---")

while True:
	client_socket, client_address = server_socket.accept()
	print(f"---CONN FROM {client_address}---")

	ch = threading.Thread(target=handler, args=(client_socket, client_address))
	ch.start()
