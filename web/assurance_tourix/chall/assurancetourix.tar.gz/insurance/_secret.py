""""Challenge response."""


CHALLENGE_RESPONSE = """
Greetings BruteNinja,

You deemed yourself worthy of the team. So welcome aboard Hack107,
Your first mission will be given to you shortly.
In the meantime, keep practising on the internet, remember that we require our partners to be at least 0xD GoD rank on tryhackme and to have at least 10517892 points on Tryhackme, which should become the prerequisite to access the first rank 'Curious'.

Also, here is the token to prove your worth to the other members of the team:

HACKDAY{8ALD_L1K3_47}
"""
