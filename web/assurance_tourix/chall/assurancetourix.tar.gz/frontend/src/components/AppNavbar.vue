<script setup lang="ts">
import { NSpace, NH3 } from 'naive-ui'
</script>

<template>
  <n-space justify="space-between" align="center">
    <n-h3>ASSURTOUT</n-h3>
  </n-space>
</template>

<style scoped>
.n-h3 {
  margin-bottom: 0;
}
.n-space {
  padding: 1.5rem 2rem;
  width: 100%;
}
</style>
