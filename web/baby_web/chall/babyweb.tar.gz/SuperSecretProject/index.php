<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../static/style.css">
  <title>Hello <?php if (isset($_COOKIE['USER'])) {
	$u=$_COOKIE['USER'];
} else {
	$u = "Anonymous";
}
echo $u;
?></title>
</head>
<?php
if (!isset($_COOKIE['USER']) or ($_COOKIE['USER'] != "DS Bandit" and $_COOKIE['USER'] != "Chelinka")) {
	$Title = "Access Forbidden";
	$Message = "You are not the USER : DS Bandit";
	$Alt = "Forbidden";
	$Pic = "Forbidden_200x200";
} else if ($_COOKIE['USER'] == "Chelinka") {
	$Title = "No";
	$Message = "Are you looking for someone else ?";
	$Alt = "No point being here";
	$Pic = "Forbidden_200x200";
} else if ($_SERVER['HTTP_USER_AGENT'] != "DS Mobile") {
	$Title = "Access Forbidden";
	$Message = "You need to be connecting from the DS Mobile";
	$Alt = "Forbidden";
	$Pic = "Forbidden_200x200";
} else {
	$Title = "Super secret project";
	$Message = "This is the preview for the new <a href='SuperUltraTech30001.zip'>SuperUltraTech30001<a> which will let me rule the world. Also, here is my token if i ever forget about it: <!--HACKDAY{WEB101}-->.";
	$Alt = "DS";
	$Pic = "DS_200x200";
}
?>

<body>
  <div class="container">
    <h1><?php echo $Title; ?></h1>
    <img src="../static/<?php echo $Pic; ?>.jpeg" alt="<?php echo $Alt; ?>">
    <p><?php echo $Message; ?></p>
  </div>
</body>
</html>
