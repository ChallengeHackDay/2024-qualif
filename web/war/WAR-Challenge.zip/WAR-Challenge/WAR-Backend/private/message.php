<?php 
    
    $servername = "war-admin";
    $username = "root";
    $password = "HACKDAY7722";
    $database = "WARAdmin";

    if(isset($_POST['username'])){
        echo("Function not implemented yet !");
        
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WAR Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #4caf50;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>

    <h2>Messages:</h2>

    <table>
        <thead>
            <tr>
                <th>Sender</th>
                <th>Message</th>
            </tr>
        </thead>
        <tbody>
<?php
    if(isset($_GET['passcode'])){
        $conn = mysqli_connect($servername, $username, $password, $database);
        if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
        }

        $query = "SELECT message_text,username FROM messages INNER JOIN users ON users.user_id = messages.sender_id  where receiver_id = (SELECT user_id FROM users WHERE passcode ='".$_GET['passcode']."')";
        #echo($query);
        try {
            $results = mysqli_query($conn, $query);
        } catch (Exception $e) {
            echo($e);
        }
        
        if($results){
            foreach($results as $line){
                echo("<tr><td>");
                echo($line['username']);
                echo("</td><td>");
                echo($line['message_text']);
                echo("</td></tr>");
            }
        }
        
         
    } 
?>
        </tbody>
    </table>

</body>
</html>
