CREATE DATABASE WARAdmin;

USE WARAdmin;

CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    passcode VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO users (username, email, password, passcode) VALUES
    ('admin', 'admin@domain.local', 'H4kD4y', '0000'),
    ('devoteam', 'devoteam@domain.local', 'D3V0T43M', '1234'),
    ('esiee', 'esiee@domain.local', 'ScH00l', '9999');

CREATE TABLE messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    message_text TEXT NOT NULL,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL
);

INSERT INTO messages (message_text, sender_id, receiver_id) VALUES
    ('Hello there!', 1, 3),
    ('Meeting at 2 PM tomorrow.', 2, 3),
    ('FIND THE FLAG.', 3, 2),
    ('Don''t forget to submit the report.', 3, 1),
    ('Happy Birthday!', 1, 2),
    ('Not working... I should try to define my own method', 3, 3),
    ('Final project presentation on Friday.', 2, 3);

CREATE FUNCTION read_file RETURNS STRING SONAME 'read_file.so';
