import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
import os
import sys
# Replace these values with your own
smtp_server = "127.0.0.1"  # Replace with the hostname or IP address of your local SMTP server
smtp_port = 587  # Default SMTP port
sender_email = "mail@example.com"
sender_password = "password"
recipient_email = str(sys.argv[1])
# Create the email message
message = MIMEMultipart()
message["Subject"] = "Check my cards !"
message["From"] = sender_email
message["To"] = recipient_email
dirPath = "/usr/src/app/pokecards/"
# Attach the body of the email
message.attach(MIMEText("Hey friend\n, you can find in attachment my favourite pokemon cards\n, do you have it?","plain"))

# Attach the image file
for imagePath in os.listdir(dirPath):
    with open(dirPath+imagePath, "rb") as file:
    	image_attachment = MIMEImage(file.read())
    	image_attachment.add_header("Content-Disposition", "attachment", filename="image.jpg")
    	message.attach(image_attachment)

# Connect to the local SMTP server
with smtplib.SMTP(smtp_server, smtp_port) as server:
    # Send the email
    server.starttls()
    server.login(sender_email, sender_password)
    server.sendmail(sender_email, recipient_email, message.as_string())

print("Email sent successfully.")
