#include <stdio.h>
#include <regex.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
void convertToLowercase(char *str) {
    while (*str) {
        *str = tolower(*str);
        str++;
    }
}

int is_valid_email(char *email) {
    size_t len = strlen(email);
    if (len > 0 && email[len - 1] == '\n') {
        email[len - 1] = '\0';
    }
    regex_t regex;
    const char *pattern = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
	
    if (regcomp(&regex, pattern, REG_EXTENDED) != 0) {
        fprintf(stderr, "Failed to compile regex\n");
        return 0;  // Regex compilation failed
    }

    int match = regexec(&regex, email, 0, NULL, 0);
    regfree(&regex);

    return (match == 0);
}

int main(){
	//directory path
	char email[100];
	int nbPokemons = 5;
	char* pokemons[] = {"poppo", "zenigame", "fushigidane", "hitokage", "rokon"};
	printf("Hi friend as a pokemon lover I want to mail you\n"
        "some of my favourites cards game, what do you think about it?\n");
	printf("Email adress: ");
	fgets(email, sizeof(email), stdin);
	if (is_valid_email(email)){
		char command[256];
                snprintf(command, sizeof(command), "python3 mailSender.py %s",email);
		int result = system(command);
                if (result == 0){
			printf("Okay well\n");
			printf("Now I have to confirm your pokemon skills\n");
			printf("Can you please specify, in the order you receive them, the Japanese names\n");
			printf("of each pokemon that I sent you?\n");
			printf("Ex: rattata --> koratta\n");
			char pokemon[50];
			int isOkay = 1;
			for (int i = 0; i < nbPokemons; i++){
				printf("Pokemon %d: ",i+1);
				fgets(pokemon, sizeof(pokemon), stdin);
				size_t len = strlen(pokemon);
				if (len	 > 0 && pokemon[len - 1] == '\n'){
					pokemon[len -1] = '\0';
				}
				convertToLowercase(pokemon);	
				if (strcmp(pokemon, pokemons[i]) != 0){
					isOkay = 0;
				}
			}
			if (isOkay == 1){
				printf("You're right !\n");
				for (int i = 0; i < 3; i++){
					printf("...\n");
					sleep(1);
				}
				snprintf(command, sizeof(command), "qrencode -t ANSI 'www.instagram.com/pikhackchuoff/'");
				int result = system(command);
				if (result != 0){
					printf("An error occured");
				}
			}else{
				printf("bad pokemons !");
			}
		}else{
			printf("An error occured, please retry");
		}
	}else{
	printf("Huuh, it doesn't seem to be an email address.");	
	}
	return 0;
}
